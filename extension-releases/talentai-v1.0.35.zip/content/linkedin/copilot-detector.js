// Inbox Copilot detector — watches for LinkedIn messaging threads and
// triggers the sidebar when the latest message in the open thread is
// inbound. Only triggers on /messaging/* (full-page messaging). Floating
// message overlays on profile pages are deliberately out of scope for v1.
//
// SPA navigation: LinkedIn doesn't fire navigation events when switching
// threads, so we poll the URL on a 1 s tick and trigger detection after
// a 1.5 s settle delay (DOM hydration takes ~700 ms after thread switch).

(function () {
  'use strict';

  const SIDEBAR_ID = 'talentai-copilot-sidebar';

  function inMessagingView() {
    return /\/messaging(\/|$)/.test(window.location.pathname);
  }

  let lastUrl = '';
  let detectTimer = null;

  function scheduleDetect() {
    if (detectTimer) clearTimeout(detectTimer);
    detectTimer = setTimeout(() => {
      if (typeof window.talentaiCopilotDetect === 'function') {
        try { window.talentaiCopilotDetect(); } catch (err) { console.warn('[copilot-detector]', err); }
      }
    }, 1500);
  }

  setInterval(() => {
    if (!inMessagingView()) {
      removeSidebar();
      lastUrl = '';
      return;
    }
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      scheduleDetect();
    }
  }, 1000);

  function removeSidebar() {
    document.getElementById(SIDEBAR_ID)?.remove();
  }
})();
