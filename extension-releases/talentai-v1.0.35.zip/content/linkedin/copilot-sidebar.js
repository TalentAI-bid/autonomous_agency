// Inbox Copilot sidebar — scrapes the open LinkedIn DM thread, asks the
// service worker to draft a reply via /api/copilot/draft-reply, and
// renders the result in a right-side editable panel.
//
// Communication is via chrome.runtime.sendMessage to the service worker
// (content scripts can't import auth-client directly). DOM scraping uses
// a defensive multi-selector cascade — every paste path falls back to
// clipboard with a clear alert if LinkedIn's structure shifts.

(function () {
  'use strict';

  const SIDEBAR_ID = 'talentai-copilot-sidebar';

  // Exposed for copilot-detector.js to call after URL changes.
  window.talentaiCopilotDetect = async function talentaiCopilotDetect() {
    const conversation = scrapeConversationThread();
    if (!conversation || conversation.messages.length === 0) {
      removeSidebar();
      return;
    }
    const last = conversation.messages[conversation.messages.length - 1];
    if (last.direction !== 'inbound') {
      // Don't draft a reply to our own outgoing message.
      removeSidebar();
      return;
    }
    renderSidebar(conversation);
    requestDraft(conversation);
  };

  // ─── Scraping ──────────────────────────────────────────────────────

  function scrapeConversationThread() {
    // Recipient identity
    const nameEl =
      document.querySelector('.msg-thread__link-to-profile h2') ||
      document.querySelector('.msg-entity-lockup__entity-title') ||
      document.querySelector('.msg-overlay-bubble-header__title');
    const recipientName = nameEl?.innerText?.trim() || '';

    const linkEl =
      document.querySelector('.msg-thread__link-to-profile') ||
      document.querySelector('a[href*="/in/"]');
    const rawHref = linkEl?.href || '';
    const recipientLinkedinUrl = rawHref ? rawHref.split('?')[0].split('#')[0] : '';

    if (!recipientName || !recipientLinkedinUrl) return null;

    // Message list — try several container selectors, then walk individual items.
    const items = document.querySelectorAll(
      '.msg-s-message-list__event, .msg-s-event-listitem, .msg-s-message-list__message',
    );
    const messages = [];

    items.forEach((item) => {
      const bodyEl =
        item.querySelector('.msg-s-event-listitem__body') ||
        item.querySelector('.msg-s-message-list__paragraph') ||
        item.querySelector('p');
      if (!bodyEl) return;
      const body = bodyEl.innerText?.trim();
      if (!body) return;

      const senderEl =
        item.querySelector('.msg-s-message-group__name') ||
        item.querySelector('.msg-s-event-listitem__name');
      const senderName = senderEl?.innerText?.trim() ?? '';

      const isOutbound =
        senderName === 'You' ||
        item.classList.contains('msg-s-message-list__event--out') ||
        item.classList.contains('msg-s-event-listitem--mine');

      const timeEl = item.querySelector('time');
      const dateTimeAttr = timeEl?.getAttribute('datetime');
      const sentAt = dateTimeAttr && !isNaN(Date.parse(dateTimeAttr))
        ? new Date(dateTimeAttr).toISOString()
        : new Date().toISOString();

      messages.push({
        direction: isOutbound ? 'outbound' : 'inbound',
        body,
        sentAt,
      });
    });

    return {
      recipientName,
      recipientLinkedinUrl,
      messages,
    };
  }

  // ─── Sidebar render ────────────────────────────────────────────────

  function renderSidebar(conversation) {
    removeSidebar();
    const sidebar = document.createElement('div');
    sidebar.id = SIDEBAR_ID;
    sidebar.innerHTML = `
      <div class="copilot-header">
        <span>🤖 TalentAI Copilot</span>
        <button id="copilot-close" aria-label="Close">×</button>
      </div>

      <div class="copilot-context">
        <strong>${escapeHtml(conversation.recipientName)}</strong>
        <div>${conversation.messages.length} messages in thread</div>
      </div>

      <div class="copilot-status">
        <div class="loading">Analyzing conversation…</div>
      </div>

      <div class="copilot-output hidden"></div>
    `;
    document.body.appendChild(sidebar);
    sidebar.querySelector('#copilot-close').addEventListener('click', removeSidebar);
  }

  async function requestDraft(conversation) {
    const sidebar = document.getElementById(SIDEBAR_ID);
    if (!sidebar) return;
    const status = sidebar.querySelector('.copilot-status');

    try {
      const response = await chrome.runtime.sendMessage({
        kind: 'copilot_draft_reply',
        payload: {
          recipientLinkedinUrl: conversation.recipientLinkedinUrl,
          recipientName: conversation.recipientName,
          conversationHistory: conversation.messages,
        },
      });
      if (!response || !response.ok) {
        const msg = response?.error || 'Failed to draft reply';
        throw new Error(msg);
      }
      renderDraft(response.draft);
    } catch (err) {
      if (!status) return;
      status.innerHTML = `<div class="error">Error: ${escapeHtml(err?.message ?? String(err))}</div>`;
    }
  }

  function renderDraft(draft) {
    const sidebar = document.getElementById(SIDEBAR_ID);
    if (!sidebar) return;
    sidebar.querySelector('.copilot-status')?.classList.add('hidden');
    const out = sidebar.querySelector('.copilot-output');
    out.classList.remove('hidden');

    const altBlock = draft.alternativeShortVersion
      ? `<details class="alt-version">
           <summary>Shorter alternative</summary>
           <div class="draft-body-alt" contenteditable="true">${escapeHtml(draft.alternativeShortVersion)}</div>
           <button class="use-alt-btn">Use this instead</button>
         </details>`
      : '';

    out.innerHTML = `
      <div class="intent-badge">${escapeHtml(formatIntent(draft.intent))} · ${escapeHtml(String(draft.confidence ?? ''))}% confident</div>
      <div class="strategy-note">Strategy: ${escapeHtml(draft.strategy ?? '')}</div>
      <div class="draft-body" id="copilot-draft-body" contenteditable="true">${escapeHtml(draft.body)}</div>
      ${altBlock}
      <div class="copilot-actions">
        <button id="paste-draft-btn">📩 Paste into Reply</button>
        <button id="regenerate-draft-btn">🔄 Regenerate</button>
        <button id="copy-draft-btn">📋 Copy</button>
      </div>
      <div class="copilot-meta">Edit inline before pasting.</div>
    `;

    sidebar.querySelector('#paste-draft-btn').addEventListener('click', () => {
      const text = sidebar.querySelector('#copilot-draft-body').innerText;
      pasteIntoComposeBox(text);
    });
    sidebar.querySelector('#regenerate-draft-btn').addEventListener('click', () => {
      window.talentaiCopilotDetect?.();
    });
    sidebar.querySelector('#copy-draft-btn').addEventListener('click', () => {
      const text = sidebar.querySelector('#copilot-draft-body').innerText;
      navigator.clipboard?.writeText(text);
    });
    sidebar.querySelector('.use-alt-btn')?.addEventListener('click', () => {
      const alt = sidebar.querySelector('.draft-body-alt').innerText;
      sidebar.querySelector('#copilot-draft-body').innerText = alt;
    });
  }

  function pasteIntoComposeBox(text) {
    const composeBox =
      document.querySelector('.msg-form__contenteditable') ||
      document.querySelector('[contenteditable="true"][role="textbox"]');
    if (!composeBox) {
      navigator.clipboard?.writeText(text);
      alert('Could not find the reply box. Text copied to clipboard — click in the LinkedIn message field and paste manually.');
      return;
    }
    composeBox.focus();
    // Clear existing content by selecting all + replacing
    try {
      const range = document.createRange();
      range.selectNodeContents(composeBox);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch {}
    document.execCommand('insertText', false, text);
  }

  function removeSidebar() {
    document.getElementById(SIDEBAR_ID)?.remove();
  }

  function formatIntent(intent) {
    const map = {
      interested_qualifying: '🔍 Interested',
      meeting_request: '📅 Meeting Request',
      pricing_inquiry: '💰 Pricing Question',
      objection_price: '⚠️ Price Objection',
      objection_timing: '⏰ Timing Objection',
      objection_solution: '🔄 Current Solution',
      objection_authority: '🔝 Not Decision-Maker',
      info_request: '📄 Info Request',
      polite_decline: '🚫 Polite Decline',
      hostile: '😡 Hostile',
      casual_chat: '☕ Casual',
      competitor_intel: '🔍 Competitor Comparison',
    };
    return map[intent] || intent;
  }

  function escapeHtml(s) {
    if (s == null) return '';
    return String(s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[c]));
  }
})();
