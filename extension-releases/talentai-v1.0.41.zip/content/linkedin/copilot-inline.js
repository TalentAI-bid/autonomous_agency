// Boot marker — outside the IIFE so even if the IIFE throws during setup
// we still see proof the content-script tag executed. Visible in DevTools
// → Console (filter by `[talentai-copilot]`).
console.log('[talentai-copilot] script-tag executed on', window.location.host + window.location.pathname);

// LinkedIn Inbox Copilot — INLINE version.
// Replaces the old sidebar UX. Injects a small ✨ button into LinkedIn's
// compose toolbar (`.msg-form`). Clicking it opens an anchored menu with
// five modes: generate from scratch, polish, shorter, more direct, different
// angle. The chosen mode + the user's in-progress text are sent to the
// service worker, which proxies POST /api/copilot/draft-reply. The reply
// body is written straight into the LinkedIn compose box; the user clicks
// LinkedIn's own Send.
//
// Comm path: content script → chrome.runtime.sendMessage({ kind: 'copilot_draft_reply' })
//            → SW handler at service-worker.js:691 → authedFetch → backend.
// Content scripts can't import auth-client.js (ES module bound to extension
// context), so SW-passing is the only path.
//
// DOM selectors below are late-2024 LinkedIn. If they shift, the button
// silently stops appearing — clipboard fallbacks in pasteIntoComposeBox
// keep the failure mode "manual paste" rather than crash.

(function () {
  'use strict';

  const BUTTON_CLASS = 'talentai-copilot-btn';
  const MENU_ID = 'talentai-copilot-menu';
  const INDICATOR_CLASS = 'talentai-copilot-indicator';
  const LOG = '[talentai-copilot]';

  // ─── Signed-in user identity ──────────────────────────────────────
  // The strongest direction signal: if a message's sender label matches
  // the signed-in user's name, it's outbound. Try several DOM selectors
  // — LinkedIn renders the user's name in slightly different chrome
  // depending on the route. Cache once per page; LinkedIn's SPA renders
  // the nav before the messaging surface, so subsequent calls reuse.
  let _cachedUserName = null;
  function getSignedInUserName() {
    if (_cachedUserName) return _cachedUserName;
    const candidates = [
      () => document.querySelector('.global-nav__me-photo[alt]')?.getAttribute('alt'),
      () => document.querySelector('img.global-nav__me-photo')?.getAttribute('alt'),
      () => document.querySelector('.global-nav__me .text-body-small')?.innerText?.trim(),
      () => document.querySelector('button[aria-label*="Me,"] img[alt]')?.getAttribute('alt'),
      () => document.querySelector('button[aria-label*="Moi,"] img[alt]')?.getAttribute('alt'),
      () => document.querySelector('[data-control-name="identity_welcome_message"] .text-heading-medium')?.innerText?.trim(),
      () => document.querySelector('.feed-identity-module__actor-meta .feed-identity-module__member-name')?.innerText?.trim(),
      // Profile-card on the messaging surface itself, when present.
      () => document.querySelector('.msg-overlay-bubble-header__title-text')?.innerText?.trim(),
    ];
    for (const fn of candidates) {
      try {
        const v = fn();
        // Reject empty + short strings ("Me", single chars) — those are
        // likely button labels, not the actual name.
        if (v && typeof v === 'string' && v.trim().length > 2) {
          _cachedUserName = v.trim();
          return _cachedUserName;
        }
      } catch (_) {
        // continue
      }
    }
    return null;
  }

  // ─── Single-primary-selector message extraction ───────────────────
  // The old multi-selector comma list caused duplication: the same DOM
  // message was matched by both .msg-s-event-listitem AND nested
  // .msg-s-message-list__message, so the scrape returned ghost rows that
  // defeated the length<2 fail-loud gate. Use exactly one selector;
  // fall back only when the primary returns zero.
  function getMessageElements(thread) {
    let items = thread.querySelectorAll('.msg-s-event-listitem');
    if (items.length > 0) return items;
    items = thread.querySelectorAll('.msg-s-message-list__event');
    if (items.length > 0) return items;
    return thread.querySelectorAll('.msg-s-message-list__message');
  }

  // ─── Direction detection by user-identity (Signal 1 + Signal 2) ───
  // Speculative class-based detection was REMOVED — the previous
  // iterations added more and more class-name guesses to an OR chain
  // without ever confirming any of them match the user's actual DOM,
  // and every guess defaulted-inbound on miss. Better to fail loud via
  // validateScrape below than to guess.
  function detectDirection(item, signedInUserName) {
    const senderEl =
      item.querySelector('.msg-s-message-group__name') ||
      item.querySelector('.msg-s-event-listitem__name') ||
      item.querySelector('[class*="message-group__name"]');
    const senderName = senderEl?.innerText?.trim() || '';

    // Signal 1: sender label matches the signed-in user's name. Allow
    // a starts-with match in either direction because LinkedIn sometimes
    // truncates ("Hatem A.") or shows just first name in grouped headers.
    if (signedInUserName && senderName) {
      const userLower = signedInUserName.toLowerCase();
      const sendLower = senderName.toLowerCase();
      if (sendLower === userLower ||
          sendLower.startsWith(userLower) ||
          userLower.startsWith(sendLower)) {
        return 'outbound';
      }
    }

    // Signal 2: localized "You" / "Vous" / "Tu" / "Du" / etc.
    if (/^(You|Vous|Tu|Du|Tú|Você|Sie|あなた|您|당신)$/i.test(senderName)) {
      return 'outbound';
    }

    return 'inbound';
  }

  // ─── Scrape validation (refuse on degenerate output) ─────────────
  function validateScrape(messages, signedInUserName) {
    if (messages.length === 0) {
      return { ok: false, reason: 'Could not read this thread. Open the conversation fully and try again.' };
    }
    if (messages.length === 1) {
      return { ok: false, reason: 'Only one message detected — open the full thread so the assistant can read the conversation, then try again.' };
    }
    if (!signedInUserName) {
      return { ok: false, reason: 'Could not detect your LinkedIn identity. Please refresh the page and try again.' };
    }
    // All-same-direction across ≥3 messages = scrape failure, not real.
    // Real outreach threads where you sent multiple unanswered messages
    // are usually ≤2 messages from the user — we'd rather false-positive
    // here than hallucinate a reply.
    if (messages.length >= 3) {
      const first = messages[0].direction;
      if (messages.every((m) => m.direction === first)) {
        return {
          ok: false,
          reason: `Scrape error: all ${messages.length} messages tagged as ${first}. LinkedIn DOM may have changed — please report this.`,
        };
      }
    }
    return { ok: true };
  }

  // Boot-time signal so the user can confirm the content script ran at
  // all. Visible in DevTools → Console (filter by [talentai-copilot]).
  console.log(`${LOG} loaded on ${window.location.hostname}${window.location.pathname}`);

  let lastScanAt = 0;
  let firstHitLogged = false;
  const scriptStartedAt = Date.now();
  let zeroFormsWarned = false;

  function scan() {
    const now = Date.now();
    if (now - lastScanAt < 500) return; // throttle
    lastScanAt = now;
    const stats = injectButtonsIntoAllComposeForms();

    // Diagnostic: log the first time we find an editor, OR once after 10 s
    // if we still haven't seen any. Editor-anchored stats let the user see
    // exactly where the pipeline broke (no editors? no form ancestor? dupe-guarded?).
    if (!firstHitLogged && stats.editors > 0) {
      firstHitLogged = true;
      console.log(`${LOG} scan: ${stats.editors} editors / ${stats.forms} forms / ${stats.injected} injected`);
    } else if (!firstHitLogged && !zeroFormsWarned && now - scriptStartedAt > 10_000) {
      zeroFormsWarned = true;
      console.log(`${LOG} scan: 0 editors found after 10s. If you're on a messaging page and the ✨ button isn't visible, LinkedIn's compose-toolbar selectors likely changed — paste an outerHTML snippet of the reply box and we'll update the selector.`);
    }
  }

  // Initial sweep + observer. LinkedIn re-renders frequently so we re-scan
  // on DOM changes too.
  setInterval(scan, 1000);
  const observer = new MutationObserver(scan);
  observer.observe(document.body, { childList: true, subtree: true });
  scan();

  function injectButtonsIntoAllComposeForms() {
    // Anchor on the editor (we have ground truth that
    // `.msg-form__contenteditable` exists from a real DOM excerpt).
    // From each editor, find the enclosing form-like container — this
    // tolerates LinkedIn renaming the outer `.msg-form` class.
    const editors = document.querySelectorAll('.msg-form__contenteditable');
    let formsFound = 0;
    let injected = 0;
    const seenForms = new WeakSet();

    editors.forEach((editor) => {
      const form =
        editor.closest('.msg-form') ||
        editor.closest('.msg-form-component') ||
        editor.closest('form') ||
        findFormByWalk(editor);
      if (!form) return;
      if (seenForms.has(form)) return; // multiple editors inside one form
      seenForms.add(form);
      formsFound += 1;

      if (form.querySelector(':scope .' + BUTTON_CLASS)) return; // dupe guard, scoped per form

      // Injection target cascade — prefer the existing icon row, then send
      // button's sibling area, then the expand-button row (confirmed
      // present in the user's DOM via the pasted snippet), then the form.
      const target =
        form.querySelector('.msg-form__left-actions') ||
        form.querySelector('.msg-form__footer') ||
        form.querySelector('.msg-form__send-button-container')?.parentElement ||
        form.querySelector('.msg-form__expand-btn-wrapper')?.parentElement ||
        form;
      if (!target) return;

      target.appendChild(createCopilotButton(form));
      injected += 1;
    });

    return { editors: editors.length, forms: formsFound, injected };
  }

  function findFormByWalk(editor) {
    // Walk up at most 8 levels, returning the deepest ancestor that
    // contains the editor AND at least one form-toolbar landmark. This
    // gives us a stable "form" even when LinkedIn renames the outer
    // .msg-form class.
    let node = editor.parentElement;
    for (let i = 0; i < 8 && node && node !== document.body; i++) {
      const hasToolbar = !!(
        node.querySelector(':scope .msg-form__send-button-container') ||
        node.querySelector(':scope .msg-form__left-actions') ||
        node.querySelector(':scope .msg-form__footer') ||
        node.querySelector(':scope .msg-form__expand-btn-wrapper')
      );
      if (hasToolbar) return node;
      node = node.parentElement;
    }
    return editor.parentElement; // fallback so the button still appears
  }

  function createCopilotButton(form) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = BUTTON_CLASS;
    btn.title = 'TalentAI Copilot — AI reply assistant';
    btn.setAttribute('aria-label', 'TalentAI Copilot');
    btn.textContent = '✨';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openCopilotMenu(form, btn);
    });
    return btn;
  }

  // ─── Anchored dropdown menu ───────────────────────────────────────

  function openCopilotMenu(form, anchorBtn) {
    document.getElementById(MENU_ID)?.remove(); // close any open menu

    const composeBox = form.querySelector('.msg-form__contenteditable');
    const existingText = (composeBox?.innerText || '').trim();
    const hasText = existingText.length > 0;

    const menu = document.createElement('div');
    menu.id = MENU_ID;
    menu.innerHTML = hasText
      ? `
        <div class="menu-header">✨ Improve your draft</div>
        <button data-mode="improve_existing">✏️ Polish this</button>
        <button data-mode="make_shorter">📏 Make shorter</button>
        <button data-mode="make_more_direct">🎯 Make more direct</button>
        <button data-mode="different_angle">🔄 Try different angle</button>
        <div class="menu-divider"></div>
        <button data-mode="generate_from_scratch" class="secondary">↻ Replace with fresh draft</button>
      `
      : `
        <div class="menu-header">✨ AI Reply Assistant</div>
        <button data-mode="generate_from_scratch">⚡ Generate reply</button>
      `;

    // Anchor menu above the button.
    const rect = anchorBtn.getBoundingClientRect();
    menu.style.position = 'fixed';
    menu.style.bottom = `${window.innerHeight - rect.top + 8}px`;
    menu.style.left = `${rect.left}px`;

    document.body.appendChild(menu);

    menu.querySelectorAll('button[data-mode]').forEach((b) => {
      b.addEventListener('click', () => {
        const mode = b.getAttribute('data-mode');
        menu.remove();
        runCopilot(form, mode, existingText).catch((err) =>
          showIndicator(form, 'error', `⚠️ ${err?.message || String(err)}`, 5000),
        );
      });
    });

    // Close on outside click. setTimeout so this listener doesn't catch
    // the same click that opened the menu.
    setTimeout(() => {
      function onDocClick(e) {
        if (!menu.contains(e.target)) {
          menu.remove();
          document.removeEventListener('click', onDocClick);
        }
      }
      document.addEventListener('click', onDocClick);
    }, 0);
  }

  // ─── Main flow ────────────────────────────────────────────────────

  async function runCopilot(form, mode, existingText) {
    const composeBox = form.querySelector('.msg-form__contenteditable');
    if (!composeBox) {
      showIndicator(form, 'error', '⚠️ Could not find LinkedIn compose box.', 5000);
      return;
    }

    showIndicator(form, 'loading', '✨ Generating…');

    const conv = scrapeConversationForForm(form);
    if (!conv || !conv.recipientName || !conv.recipientLinkedinUrl) {
      showIndicator(form, 'error', '⚠️ Could not detect conversation context.', 5000);
      return;
    }

    // Diagnostic log — the user can verify in DevTools that we read the
    // actual thread before sending to the backend. If the message count
    // is low OR all messages have the same direction across a long
    // thread, validateScrape will have set scrapeError and we'll bail.
    const outboundN = conv.messages.filter((m) => m.direction === 'outbound').length;
    const inboundN = conv.messages.filter((m) => m.direction === 'inbound').length;
    const lastDir = conv.messages[conv.messages.length - 1]?.direction ?? 'unknown';
    console.log(
      `${LOG} scrape: ${conv.messages.length} messages (${outboundN} outbound / ${inboundN} inbound) for "${conv.recipientName}"`,
    );
    console.log(`${LOG} scrape: last message direction = ${lastDir}`);
    console.log(`${LOG} scrape: signed-in user identity = ${conv.signedInUserName || '(NOT DETECTED)'}`);

    // Fail-loud: refuse to send to the API if validateScrape flagged a
    // degenerate scrape. Better an error pill than a hallucinated draft.
    if (conv.scrapeError) {
      console.warn(`${LOG} scrape validation FAILED:`, conv.scrapeError);
      showIndicator(form, 'error', `⚠️ ${conv.scrapeError}`, 6000);
      return;
    }

    // Trim to last 10 turns. The model only needs recent context and we
    // don't want to blow the prompt budget on very long threads.
    const recent = conv.messages.slice(-10);

    const payload = {
      recipientLinkedinUrl: conv.recipientLinkedinUrl,
      recipientName: conv.recipientName,
      recipientCompany: conv.recipientCompany || undefined,
      recipientTitle: conv.recipientTitle || undefined,
      conversationHistory: recent,
      mode,
      existingDraft: existingText || undefined,
    };

    let response;
    try {
      response = await chrome.runtime.sendMessage({
        kind: 'copilot_draft_reply',
        payload,
      });
    } catch (err) {
      showIndicator(form, 'error', `⚠️ ${err?.message || String(err)}`, 5000);
      return;
    }

    if (!response || !response.ok) {
      const msg = response?.error || 'Failed to draft reply';
      const friendly = /no_session|session_expired/.test(msg)
        ? 'Please sign in to TalentAI from the extension popup first.'
        : msg;
      showIndicator(form, 'error', `⚠️ ${friendly}`, 5000);
      return;
    }

    const draft = response.draft;
    if (!draft || typeof draft.body !== 'string') {
      showIndicator(form, 'error', '⚠️ Empty draft from server. Please retry.', 5000);
      return;
    }

    replaceComposeBoxContent(composeBox, draft.body);

    // Build the success indicator with mode + intent + model so the user
    // can visually confirm Kimi was called and the right mode ran.
    const modeLabel = draft.conversationMode === 'followup' ? 'Followup' : formatIntent(draft.intent);
    const detail = draft.conversationMode === 'followup'
      ? ` (${draft.intent})` // e.g. (first_followup)
      : (typeof draft.confidence === 'number' ? ` (${draft.confidence}%)` : '');
    const modelTag = draft.model ? ` · ${draft.model}` : '';
    showIndicator(form, 'success', `✅ ${modeLabel}${detail}${modelTag}`, 4000);
  }

  // ─── Conversation scraping ────────────────────────────────────────

  function scrapeConversationForForm(form) {
    // Find the closest thread container the compose form belongs to.
    const thread =
      form.closest('.msg-thread, .msg-overlay-conversation-bubble') ||
      form.closest('[data-msg-overlay-bubble]') ||
      document.querySelector('.msg-thread');
    if (!thread) return null;

    const nameEl =
      thread.querySelector('.msg-thread__link-to-profile h2') ||
      thread.querySelector('.msg-entity-lockup__entity-title') ||
      thread.querySelector('.msg-overlay-bubble-header__title') ||
      document.querySelector('.msg-overlay-bubble-header__title');
    const recipientName = nameEl?.innerText?.trim() || '';

    const linkEl =
      thread.querySelector('.msg-thread__link-to-profile') ||
      thread.querySelector('a[href*="/in/"]');
    const rawHref = linkEl?.href || '';
    const recipientLinkedinUrl = rawHref ? rawHref.split('?')[0].split('#')[0] : '';

    if (!recipientName || !recipientLinkedinUrl) return null;

    const signedInUserName = getSignedInUserName();
    const items = getMessageElements(thread);
    const messages = [];
    const seen = new Set(); // dedup guard: same body+timestamp = same message

    items.forEach((item, index) => {
      const bodyEl =
        item.querySelector('.msg-s-event-listitem__body') ||
        item.querySelector('.msg-s-message-list__paragraph') ||
        item.querySelector('p');
      if (!bodyEl) return;
      const body = bodyEl.innerText?.trim();
      if (!body) return;

      const timeEl = item.querySelector('time');
      const dt = timeEl?.getAttribute('datetime');
      const dedupTime = dt && !isNaN(Date.parse(dt)) ? new Date(dt).toISOString() : `index-${index}`;
      const dedupKey = `${body}|${dedupTime}`;
      if (seen.has(dedupKey)) return;
      seen.add(dedupKey);

      const direction = detectDirection(item, signedInUserName);

      const sentAt = dt && !isNaN(Date.parse(dt))
        ? new Date(dt).toISOString()
        : new Date().toISOString();

      messages.push({ direction, body, sentAt });
    });

    const validation = validateScrape(messages, signedInUserName);
    return {
      recipientName,
      recipientLinkedinUrl,
      recipientCompany: '',
      recipientTitle: '',
      messages,
      signedInUserName,
      scrapeError: validation.ok ? undefined : validation.reason,
    };
  }

  // ─── Compose-box driver ───────────────────────────────────────────

  function replaceComposeBoxContent(composeBox, newText) {
    composeBox.focus();
    // Select all existing content, then insertText replaces it. Dispatching
    // an InputEvent afterwards is what triggers LinkedIn's reactive form to
    // pick the change up (send button enables, character counter updates).
    try {
      const range = document.createRange();
      range.selectNodeContents(composeBox);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch (_) {
      // Best-effort — fall through to insertText
    }
    document.execCommand('insertText', false, newText);
    composeBox.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true }));
  }

  // ─── Status indicator ─────────────────────────────────────────────

  function showIndicator(form, state, text, autoHideMs) {
    form.querySelector('.' + INDICATOR_CLASS)?.remove();
    const el = document.createElement('div');
    el.className = `${INDICATOR_CLASS} ${state}`;
    el.textContent = text;
    form.appendChild(el);
    if (autoHideMs) {
      setTimeout(() => el.remove(), autoHideMs);
    }
  }

  function formatIntent(intent) {
    const map = {
      interested_qualifying: 'Interested',
      meeting_request: 'Meeting Request',
      pricing_inquiry: 'Pricing Question',
      objection_price: 'Price Objection',
      objection_timing: 'Timing Objection',
      objection_solution: 'Has Solution',
      objection_authority: 'Not Decision-Maker',
      info_request: 'Info Request',
      polite_decline: 'Polite Decline',
      hostile: 'Hostile',
      casual_chat: 'Casual',
      competitor_intel: 'Comparison',
    };
    return map[intent] || intent || 'Drafted';
  }
})();
