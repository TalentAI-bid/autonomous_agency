// ─── Google Maps scraping core ──────────────────────────────────────────────
// Self-contained module: extraction + feed pagination + normalized records.
// Exposes `window.__mapsCore`. Deliberately has ZERO dependencies on the rest
// of the extension (no __talentaiUtils, no service-worker conventions) so it
// can be copied verbatim into a standalone Google-Maps-only project.
//
// BusinessRecord = {
//   name: string,            // required
//   category: string,        // '' if missing
//   address: string,         // '' if missing
//   phone: string|null,      // place-detail pages only
//   website: string|null,
//   rating: number|null,
//   reviewCount: number|null,
//   mapsUrl: string,         // canonical place URL — stable dedup key
//   location: string,        // search location context (caller-supplied)
// }

(() => {
  if (window.__mapsCore) return; // avoid re-injection (static + dynamic paths)

  // ── Minimal DOM helpers (intentionally duplicated from the host app) ──────

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function jitter(ms, fraction = 0.3) {
    return Math.max(0, Math.round(ms + (Math.random() * 2 - 1) * fraction * ms));
  }

  function waitForSelector(selector, { timeout = 15000, root = document } = {}) {
    return new Promise((resolve, reject) => {
      const existing = root.querySelector(selector);
      if (existing) return resolve(existing);
      const obs = new MutationObserver(() => {
        const el = root.querySelector(selector);
        if (el) {
          obs.disconnect();
          resolve(el);
        }
      });
      obs.observe(root === document ? document.documentElement : root, { childList: true, subtree: true });
      setTimeout(() => {
        obs.disconnect();
        reject(new Error(`waitForSelector timeout: ${selector}`));
      }, timeout);
    });
  }

  async function scrollContainer(el, { steps = 3, delayMs = 900 } = {}) {
    if (!el) return;
    for (let i = 0; i < steps; i++) {
      const prev = el.scrollTop;
      el.scrollBy(0, Math.max(400, el.clientHeight * 0.9));
      await sleep(jitter(delayMs));
      if (el.scrollTop === prev) break; // reached bottom
    }
  }

  function extractText(el, selector) {
    if (!el) return '';
    const target = selector ? el.querySelector(selector) : el;
    if (!target) return '';
    return (target.textContent ?? '').trim().replace(/\s+/g, ' ');
  }

  function absoluteUrl(href) {
    if (!href) return '';
    try { return new URL(href, location.href).toString(); } catch (_) { return href; }
  }

  // ── Page predicates / guards ───────────────────────────────────────────────

  function guardHost() {
    return /(^|\.)google\.[a-z.]+$/i.test(location.hostname || '');
  }

  function isMapsSearchPage() {
    if (!guardHost()) return false;
    return location.pathname.startsWith('/maps/search') || !!getFeedEl();
  }

  function isMapsPlacePage() {
    if (!guardHost()) return false;
    return location.pathname.startsWith('/maps/place');
  }

  function getFeedEl() {
    return (
      document.querySelector('div[role="feed"]') ||
      document.querySelector('div[aria-label*="Results"]')
    );
  }

  // ── Extraction ─────────────────────────────────────────────────────────────

  function extractCard(anchor, { location: locationCtx = '' } = {}) {
    const mapsUrl = absoluteUrl(anchor.getAttribute('href') || '').split('?')[0];
    if (!mapsUrl) return null;

    // Walk up to the row/card container
    const card = anchor.closest('[role="article"]') || anchor.closest('div[jsaction]') || anchor.parentElement;
    if (!card) return null;

    const name = extractText(anchor, '[role="heading"]') || extractText(anchor) || (() => {
      // Last-ditch: derive from URL
      const m = mapsUrl.match(/\/place\/([^/]+)\//);
      return m ? decodeURIComponent(m[1].replace(/\+/g, ' ')) : '';
    })();
    if (!name) return null;

    const ratingNode = card.querySelector('span.MW4etd, span[aria-label*="stars"]');
    const reviewsNode = card.querySelector('span.UY7F9, span[aria-label*="reviews"]');
    const rating = ratingNode ? parseFloat((ratingNode.textContent || '').trim()) || null : null;
    const reviewsTxt = reviewsNode ? (reviewsNode.textContent || '').replace(/[^\d]/g, '') : '';
    const reviewCount = reviewsTxt ? parseInt(reviewsTxt, 10) : null;

    // Address + category are typically in comma-separated rows within the card
    const infoBlocks = Array.from(card.querySelectorAll('.W4Efsd')).map((el) => (el.textContent || '').trim());
    const address = infoBlocks.find((t) => /\d/.test(t) && t.length > 6) || '';
    const category = infoBlocks[0] && !/\d/.test(infoBlocks[0]) ? infoBlocks[0].split('·')[0].trim() : '';

    const websiteAnchor = card.querySelector('a[data-value="Website"], a[aria-label*="Website"]');
    const website = websiteAnchor?.getAttribute('href') || null;

    return {
      name,
      category,
      address,
      phone: null, // not rendered on search cards; place pages only
      website,
      rating,
      reviewCount,
      mapsUrl,
      location: locationCtx,
    };
  }

  // Extract all currently-rendered search cards. No scrolling.
  function extractLoaded({ location: locationCtx = '' } = {}) {
    if (!guardHost()) return [];
    const feed = getFeedEl();
    if (!feed) return [];

    const seen = new Set();
    const businesses = [];
    for (const a of feed.querySelectorAll('a[href*="/maps/place/"]')) {
      const record = extractCard(a, { location: locationCtx });
      if (!record || seen.has(record.mapsUrl)) continue;
      seen.add(record.mapsUrl);
      businesses.push(record);
    }
    return businesses;
  }

  // Scroll the results feed one increment to lazy-load more cards.
  // Returns { count, atEnd } — atEnd when the card count stopped growing.
  async function loadMore(feedEl, { steps = 3, delayMs = 900 } = {}) {
    if (!guardHost()) return { count: 0, atEnd: true };
    const feed = feedEl || getFeedEl();
    if (!feed) return { count: 0, atEnd: true };

    const before = feed.querySelectorAll('a[href*="/maps/place/"]').length;
    await scrollContainer(feed, { steps, delayMs });
    await sleep(jitter(600));
    const count = feed.querySelectorAll('a[href*="/maps/place/"]').length;
    return { count, atEnd: count === before };
  }

  // Full search run: wait for feed, scroll until limit/end, extract.
  async function scrapeSearch({ limit = 20, location: locationCtx = '' } = {}) {
    if (!guardHost()) {
      return { businesses: [], debug: { reason: 'non_gmaps_host', host: location.hostname, href: location.href } };
    }
    const max = Math.min(100, limit || 20);

    const feed = await waitForSelector('div[role="feed"], div[aria-label*="Results"]', { timeout: 15000 })
      .catch(() => null);
    if (!feed) throw new Error('gmaps_no_results_feed');

    // Scroll until we've loaded >= max results or the feed stops growing.
    let stableIterations = 0;
    for (let i = 0; i < 20; i++) {
      const { count, atEnd } = await loadMore(feed);
      if (count >= max) break;
      if (atEnd) {
        stableIterations++;
        if (stableIterations >= 3) break; // reached the end
      } else {
        stableIterations = 0;
      }
    }

    const businesses = extractLoaded({ location: locationCtx }).slice(0, max);
    return { businesses };
  }

  // Place-detail run: extract a single record from a /maps/place/ page.
  async function scrapePlace({ mapsUrl = '' } = {}) {
    if (!guardHost()) {
      return { debug: { reason: 'non_gmaps_host', host: location.hostname, href: location.href } };
    }

    await Promise.race([
      waitForSelector('h1.DUwDvf', { timeout: 15000 }).catch(() => null),
      waitForSelector('div[role="main"]', { timeout: 15000 }).catch(() => null),
    ]);

    const name = extractText(document, 'h1.DUwDvf') || extractText(document, 'h1');

    const ratingTxt = extractText(document, 'div.F7nice span[aria-hidden="true"]') || extractText(document, 'span.ceNzKf');
    const reviewsTxt = extractText(document, 'div.F7nice button[aria-label*="reviews"]') || extractText(document, 'button[jsaction*="reviewChart"]');
    const rating = ratingTxt ? parseFloat(ratingTxt.trim()) || null : null;
    const reviewCount = reviewsTxt ? parseInt(reviewsTxt.replace(/[^\d]/g, ''), 10) || null : null;

    const category = extractText(document, 'button[jsaction*="category"]');
    const address = findByDataItemId('address');
    const phone = findByDataItemId('phone:tel:') || null;
    const website = findByDataItemId('authority') || null; // Google tags website rows as "authority"
    const hours = findByDataItemId('oh');

    return {
      name,
      category,
      address,
      phone,
      website,
      rating,
      reviewCount,
      mapsUrl: mapsUrl || location.href.split('?')[0],
      location: '',
      hours,
    };
  }

  function findByDataItemId(prefix) {
    const nodes = document.querySelectorAll('button[data-item-id], a[data-item-id]');
    for (const n of nodes) {
      const v = n.getAttribute('data-item-id') || '';
      if (v.startsWith(prefix)) {
        if (n.tagName === 'A' && (n.getAttribute('href') || '').startsWith('http')) {
          return n.getAttribute('href');
        }
        const label = n.getAttribute('aria-label') || n.textContent || '';
        return label.replace(/^[^:]+:\s*/, '').trim();
      }
    }
    return '';
  }

  window.__mapsCore = {
    guardHost,
    isMapsSearchPage,
    isMapsPlacePage,
    getFeedEl,
    extractLoaded,
    loadMore,
    scrapeSearch,
    scrapePlace,
  };
})();
